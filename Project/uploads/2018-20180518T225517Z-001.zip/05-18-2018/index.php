<?php
include 'conn.php';
$abc = mysqli_query($conn,"SELECT Proj_ID FROM tblproject ORDER BY Proj_ID DESC LIMIT 1");
$abcRes = $abc->fetch_assoc();
$Global_Id = $abcRes['Proj_ID'] + 1;
?>

<html>
    <head>
        <title>Ex credit</title>
        <link rel = "stylesheet" type = "text/css" href="style.css">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
            body {font-family: Arial;}

            /* Style the tab */
            .tab {
                overflow: hidden;
                border: 1px solid #ccc;
                background-color: #f1f1f1;
            }

            /* Style the buttons inside the tab */
            .tab label {
                
                background-color: inherit;
                padding-right: 8px;
                padding-left: 8px;
                text-align: center;
                display: block;
                float: left;
                width: auto;
                border-right: 1px solid #ccc;
                outline: none;
                cursor: pointer;
                transition: 0.3s;
                font-size: 14px;
            }

            /* Change background color of buttons on hover */
            .tab label:hover {
                background-color: #ddd;
            }

            /* Create an active/current tablink class */
            .tab label.active {
                background-color: #ccc;
            }

            /* Style the tab content */
            .tabcontent {
                display: none;
                padding: 6px 12px;
                border: 1px solid #ccc;
                border-top: none;
            }
        </style>
    </head>

    <body>

        <div id  = "naviBar">
            <h1>LaGuardia Community College</h1>
            <form>
                Project ID#
                <select formaction="retrieve.php" id="pid" onchange="showData(this.value);">
                    <option disabled selected value>Select a Project ID#</option>
                    <?php
                    $sql = mysqli_query($conn, "SELECT proj_id FROM tblproject GROUP BY proj_id");
                    while ($row = $sql->fetch_assoc()){
                        echo "<option value='".$row['proj_id']."'>" . $row['proj_id'] . "</option>";
                    }
                    ?>
                </select>
                Project Name: 
                <select formaction="retrieve.php" onchange="showDataByName(this.value)">
                    <option disabled selected value>Select a Project Name</option>
                    <?php
                    $sql = mysqli_query($conn, "SELECT proj_name FROM tblproject GROUP BY proj_name");
                    while ($row = $sql->fetch_assoc()){
                        echo "<option value='".$row['proj_name']."'>" . $row['proj_name'] . "</option>";
                    }
                    ?>
                </select>
                Project Building: 
                <select>
                    <option disabled selected value>Select a Project Building</option>
                    <?php
                    $sql = mysqli_query($conn, "SELECT proj_building FROM tblproject GROUP BY proj_building");
                    while ($row = $sql->fetch_assoc()){
                        echo "<option value=\"user1\">" . $row['proj_building'] . "</option>";
                    }
                    ?>
                </select>
                Project Status: 
                <select>
                    <option disabled selected value>Select a Project Status</option>
                    <?php
                    $sql = mysqli_query($conn, "SELECT proj_status FROM tblproject GROUP BY proj_status");
                    while ($row = $sql->fetch_assoc()){
                        echo "<option value=\"user1\">" . $row['proj_status'] . "</option>";
                    }
                    ?>
                </select>
            </form>
        </div>

        <form action="post1.php" method="post" enctype="multipart/form-data"> 
            <input type="hidden" id="Proj_ID" value="<?php $Global_Id; ?>">
            
            <div class = "formRight">
                <label>Priority Level: </label>
                <select name="priorityLevel" id="priorityLevel">
                    <option disabled selected value>Select a Priority Level</option>
                    <option value="general">General</option>
                    <option value="Urgent">Urgent</option>
                    <option value="Extremely Urgent">Extremely Urgent</option>
                </select><br>
                <label>Building:</label>
                <select name="building" id = "building" required>
                    <option disabled selected value>Select a Building</option>
                    <option value="E">E</option>
                    <option value="B">B</option>
                    <option value="C">C</option>
                </select><br>
                <label>Location:</label>
                <input type="text" name="location" id="location"><br>
                <label>Service Provided:</label>  
                <select name="servicePro" id="serviceProvided">
                    <option disabled selected value>Select a Service</option>
                    <option value="window">Window</option>
                    <option value="Roof">Roof</option>
                    <option value="paint">Paint</option>
                    <option value="maintainance">Maintainance</option>

                </select><br>
                <label>Status:</label>
                <select name="status" id = "status" required>
                    <option disabled selected value>Select a Status</option>
                    <option value="E"></option>
                    <option value="UnderProcess">Under Process</option>
                    <option value="Completed">Completed</option>

                </select><br>
            </div>

            <div class = "formRight"> 
                <table>
                    <tr>
                        <th scope="row"></th>
                        <th scope="row"></th>
                        <th scope="row">Amount</th>
                        <th scope="row">Fy Received</th>
                        <th scope="row">Contact Info</th>
                    </tr>

                    <tr>
                        <th scope="col">Boro President:</th>
                        <td><input type = "checkbox" name = "boroCheck" id="checkbox1" onclick="checkforboro()"></td>
                        <td><input type = "text" name="boroAm" id="boroAm" disabled></td>
                        <td><input type = "text" name="boroFy" id="boroFy" disabled></td>
                        <td><input type = "text" name="boroCont" id="boroCont" disabled></td>
                    </tr>

                    <tr>
                        <th scope="col">City Council:</th>
                        <td><input type = "checkbox" name = "citycheck" id="checkbox2" onclick="checkforcitycouncil()"></td>
                        <td><input type = "text" name="cityAm" id="cityAm" disabled></td>
                        <td><input type = "text" name="cityFy" id="cityFy" disabled></td>
                        <td><input type = "text" name="cityCont" id="cityCont" disabled></td>
                    </tr>

                    <tr>
                        <th scope="col">Mayor:</th>
                        <td><input type = "checkbox" name="mayorCheck" id="checkbox3" onclick="checkformayor()"></td>
                        <td><input type = "text" name="mayorAm" id="mayorAm" disabled></td>
                        <td><input type = "text" name="mayorFy" id="mayorFy" disabled></td>
                        <td><input type = "text" name="mayorCont" id="mayorCont" disabled></td>
                    </tr>

                    <tr>
                        <th scope="col">In House:</th>
                        <td><input type = "checkbox" name="inCheck" id="checkbox4" onclick="checkforinhouse()"></td>
                        <td><input type = "text" name="inAm" id="inAm" disabled></td>
                        <td><input type = "text" name="inFy" id="inFy" disabled></td>
                    </tr>

                    <tr>
                        <th scope="col">Capital Project:</th>
                        <td><input type = "checkbox" name="capitalCheck" id="checkbox5" onclick="checkforcapitalproject()"></td>
                        <td><input type = "text" name="capitalAm" id="capitalAm" disabled></td>
                        <td><input type = "text" name="capitalFy" id="capitalFy" disabled></td>

                    </tr>

                    <tr>
                        <th scope="col">CUNY 2020:</th>
                        <td><input type = "checkbox" name="cunyCheck" id="checkbox6" onclick="checkforcuny()"></td>
                        <td><input type = "text" name="cunyAm" id="cunyAm" disabled></td>
                        <td><input type = "text" name="cunyFy" id="cunyFy" disabled></td>

                    </tr>

                    <tr>
                        <th scope="col">SAM CCAP:</th>
                        <td><input type = "checkbox" name="samCheck" id="checkbox7" onclick="checkforsam()"></td>
                        <td><input type = "text" name="samAm" id="samAm" disabled></td>
                        <td><input type = "text" name="samFy" id="samFy" disabled></td>

                    </tr>

                    <tr>
                        <th scope="col">Private Grant:</th>
                        <td><input type = "checkbox" name="priCheck" id="checkbox8" onclick="checkforprivategrant()"></td>
                        <td><input type = "text" name="priAm" id="priAm"disabled></td>
                        <td><input type = "text" name="priFy" id="priFy" disabled></td>

                    </tr>

                    <tr>
                        <th scope="col">Federal State:</th>
                        <td><input type = "checkbox" name="fedCheck"id="checkbox9" onclick="checkforfedstate()"></td>
                        <td><input type = "text" name="fedAm" id="fedAm"disabled></td>
                        <td><input type = "text" name="fedFy" id="fedFy" disabled></td>

                    </tr>

                    <tr>
                        <th scope="col">DCAS/Operating:</th>
                        <td><input type = "checkbox" name="doCheck" id="checkbox10" onclick="checkforoperating()"></td>
                        <td><input type = "text" name="doAm" id="doAm" disabled></td>
                        <td><input type = "text" name="doFy" id="doFy" disabled></td>


                    </tr>

                    <tr>
                        <th scope="col">DCAS/CAP:</th>
                        <td><input type = "checkbox" name="dcCheckbox" id="checkbox11" onclick="checkforcap()"></td>
                        <td><input type = "text" name="dcAm" id="dcAm" disabled></td>
                        <td><input type = "text" name="dcFy" id="dcFy" disabled></td>

                    </tr>

                    <tr>
                        <th scope="col">Energy Conservation:</th>
                        <td><input type = "checkbox" name="energyCheck" id="checkbox12" onclick="checkforenergy()"></td>
                        <td><input type = "text" name="energyAm" id="energyAm" disabled></td>
                        <td><input type = "text" name="energyFy" id="energyFy" disabled></td>

                    </tr>
                </table>
            </div>
                
               <div class="formLeft">
                <label>Project Name:</label>

                <input type="text" name="projectName" id="projectName" required><br>
                <label>Project#:</label> 
                <input type = "text" name="projectNum" id="projectNum" required><br>
                <label>Project Type:</label> <input type="text" name="projectType" id="projectType"><br>
                <label>Project Start Date:</label> 
                <input type="date" name = "projectStart" id="projectStart"><br>
                <label>Completion date: </label>
                <input type = "date" name="completionDate"><br>
                <label>Design Team Cost: </label>
                <input type="text" name="designTeam" id="designTeamCost" onchange="add()"><br>

                <label>Design Cost:</label>
                <input type="text" name="designCost" id="designCost" onchange="add()"><br>            
                <label>Construction cost:</label>
                <input type="text" name="constCost" id="constructionCost" onchange="add()"><br>

                <label>FE Cost: </label>
                <input type="text" name = "fe" id= "feCost" onchange="add()"><br>
                <label>Management Cost: </label>
                <input type="text" name="manageCost" id="managementCost" onchange="add()"><br>
                <label>Total Cost:</label>
                <input type="text" name="totalCost" value="" id="totalCost"><br>

            </div>

            <div>
                Project Overview:<br>
                <textarea rows="4" cols="50" name="projectOverview" id = "projectOverview"></textarea>
            </div>




            <br><br>
            <div class="tab">
                <label class="tablinks" onclick="openCity(event, 'meetingminutes')">Meeting Minutes</label>
                <label class="tablinks" onclick="openCity(event, 'designbasis')">Request and Design Basis</label>
                <label class="tablinks" onclick="openCity(event, 'scopechange')">Request for Scope Change</label>
                <label class="tablinks" onclick="openCity(event, 'costestimates')">Cost Estimastes</label>
                <label class="tablinks" onclick="openCity(event, 'buildingdeparment')">Building Deparment</label>
                <label class="tablinks" onclick="openCity(event, 'biddocuments')">Bid Documents</label>
                <label class="tablinks" onclick="openCity(event, 'inspectionreport')">Inspection Report</label>
                <label class="tablinks" onclick="openCity(event, 'FandE')">F and E</label>
                <label class="tablinks" onclick="openCity(event, 'closeout')">Closeout</label>
            </div>

             
            <div id="meetingminutes" class="tabcontent">
                <b>Meeting Minutes</b><br>

                Description of File: <input type="text" name="description_entered"/><br>
                <input type="file" name="file[]" multiple /><br>
                

            </div>
            <div id="designbasis" class="tabcontent">

                <b>Request and Design Basis</b><br>
                Description of File: <input type="text" name="description_entered"/><br>
                <input type="file" name="file[]" multiple /><br>
                <input type="submit" name="submitbasis"/>

            </div>

            <div id="scopechange" class="tabcontent">
                <b>Request for Scope Change</b><br>

                Description of File: <input type="text" name="description_entered"/><br>
                <input type="file" name="file[]" multiple /><br>
                <input type="submit" name="submitScopeChange"/>
            </div>

            <div id="costestimates" class="tabcontent">
                <b>Cost Estimates</b><br>

                Description of File: <input type="text" name="description_entered"/><br>
                <input type="file" name="file[]" multiple /><br>
                <input type="submit" name="submitCostEstimates" value="upload" />
            </div>

            <div id="buildingdeparment" class="tabcontent">
                <b>Building Deparment</b><br>

                Description of File: <input type="text" name="description_entered"/><br>
                <input type="file" name="file[]" multiple /><br>
                <input type="submit" name="submitBuildingDepart" value="upload" />
            </div>

            <div id="biddocuments" class="tabcontent">
                <b>Bid Documents</b><br>

                Description of File: <input type="text" name="description_entered"/><br>
                <input type="file" name="file[]" multiple /><br>
                <input type="submit" name="submitBidDocument" value="upload" />
            </div>

            <div id="inspectionreport" class="tabcontent">
                <b>Inspection Report</b><br>
                Description of File: <input type="text" name="description_entered"/><br>
                <input type="file" name="file[]" multiple /><br>
                <input type="submit" name="submitInspectReport" value="upload" />
            </div>

            <div id="FandE" class="tabcontent">
                <b>F and E</b><br>

                Description of File: <input type="text" name="description_entered"/><br>
                <input type="file" name="file[]" multiple /><br>
                <input type="submit" name="submitFE" value="upload" />
            </div>

            <div id="closeout" class="tabcontent">
                <b>Closeout</b><br>
                Description of File: <input type="text" name="description_entered"/><br>
                <input type="file" name="file[]" multiple /><br>
                <input type="submit" name="submitCloseOut" value="upload" />
            </div>
            <input type="submit" name = "submitFiles" value ="Save">
            <input type="reset" value="Clear">
        </form>


        <script type="text/javascript" src="js/jquery.js"></script>
        <script type = "text/javascript" src="../updatedExCredit/js/check.js"></script>
        <script>
            function showData(str) {
                $.ajax({
                    url  :"database.php", //php page URL where we post this data to view from database
                    type :'POST',
                    data: ({pid: str}),
                    success: function(data){
                        console.log(data);
                        var obj = JSON.parse(data);
                        $('#Proj_ID').val(obj.Proj_ID); 
                        $('#projectName').val(obj.Proj_Name); 
                        $('#projectNum').val(obj.Proj_Number);
                        $('#projectType').val(obj.Proj_Type);
                        
                        $('#Proj_St_Date').val(obj.Proj_St_Date);
							$('#Proj_Comp_Date').val(obj.Proj_Comp_Date);
                        $('#designTeamCost').val(obj.Proj_Design_Team);
                        $('#designCost').val(obj.Proj_Design_Cost);
                        $('#constructionCost').val(obj.Proj_Const_Cost);
                        $('#feCost').val(obj.Proj_FE_Cost);
                        $('#managementCost').val(obj.Proj_Management_Cost);
                        $('#projectOverview').val(obj.Proj_Overview);
                        $('#building').val(obj.Proj_Building);
                        $('#location').val(obj.Proj_Location);
                        $('#serviceProvided').val(obj.Proj_Serv_Provider);
                        $('#status').val(obj.Proj_Status);
                        $('#totalCost').val(obj.TotalCost);
                    }
                });
            }

            function openCity(evt, cityName) {
                var i, tabcontent, tablinks;
                tabcontent = document.getElementsByClassName("tabcontent");
                for (i = 0; i < tabcontent.length; i++) {
                    tabcontent[i].style.display = "none";
                }
                tablinks = document.getElementsByClassName("tablinks");
                for (i = 0; i < tablinks.length; i++) {
                    tablinks[i].className = tablinks[i].className.replace(" active", "");
                }
                document.getElementById(cityName).style.display = "block";
                evt.currentTarget.className += " active";
            }

        </script>

    </body>
</html>