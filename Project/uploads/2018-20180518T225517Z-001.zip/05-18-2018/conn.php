<?php

$conn = mysqli_connect("localhost","root","iwouldntsayyes1","extraCredit");
if(!$conn)
{
    die("Connection Failed".mysqli_error($conn));
}
?>
