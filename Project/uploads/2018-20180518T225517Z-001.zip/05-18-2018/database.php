<?php
	$fn = $_POST['pid'];
	
	include 'conn.php';

    
            $sql = mysqli_query($conn, "SELECT * FROM tblproject WHERE proj_id = ".$fn);
            $row = $sql->fetch_assoc();
            echo json_encode($row);
