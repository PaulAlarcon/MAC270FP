<?php
include 'conn.php';
?>
<html>

    <head>
        <title></title>
    </head>

    <body>

        <?php
        $Proj_ID = mysqli_real_escape_string($conn, $_POST['$Proj_ID']);
        $ProjName = mysqli_real_escape_string($conn, $_POST['projectName']);
        $ProjectNumber  = mysqli_real_escape_string($conn, $_POST['projectNum']);
        $ProjectType  = mysqli_real_escape_string($conn, $_POST['projectType']);
        $ProjectStartDate  = mysqli_real_escape_string($conn, $_POST['projectStart']);
        $CompletionDate =  mysqli_real_escape_string($conn, $_POST['completionDate']);
        $Desing_Team  = mysqli_real_escape_string($conn, $_POST['designTeam']);
        $Desing_Cost  = mysqli_real_escape_string($conn, $_POST['designCost']);
        $Construction_Cost  = mysqli_real_escape_string($conn, $_POST['constCost']);
        $FE_Cost  = mysqli_real_escape_string($conn, $_POST['fe']);
        $Management_Cost  = mysqli_real_escape_string($conn, $_POST['manageCost']);
        $Total_Cost  = mysqli_real_escape_string($conn, $_POST['totalCost']);

        //Project Overview
        $Project_Over = mysqli_real_escape_string($conn,$_POST['projectOverview']);
        //Priority Level

        $Priority_Level  = mysqli_real_escape_string($conn, $_POST['priorityLevel']);
        $Building  = mysqli_real_escape_string($conn, $_POST['building']);
        $Location  = mysqli_real_escape_string($conn, $_POST['location']);
        $Service_Provided  = mysqli_real_escape_string($conn, $_POST['servicePro']);
        $Status  = mysqli_real_escape_string($conn, $_POST['status']);

        //Amount, FY receieved, Contact Info   
        //Boro President
        //if (boroCheck){}
        $Boro_Am  = mysqli_real_escape_string($conn, $_POST['boroAm']);
        $Boro_Fy  = mysqli_real_escape_string($conn, $_POST['boroFy']);
        $Boro_Cont  = mysqli_real_escape_string($conn, $_POST['boroCont']);

        //City Council
        //if (cityCheck){}
        $City_Am  = mysqli_real_escape_string($conn, $_POST['cityAm']);
        $City_Fy  = mysqli_real_escape_string($conn, $_POST['cityFy']);
        $City_Cont  = mysqli_real_escape_string($conn, $_POST['cityCont']);

        //Mayor
        //if (mayorCheck){}
        $Mayor_Am  = mysqli_real_escape_string($conn, $_POST['mayorAm']);
        $Mayor_Fy  = mysqli_real_escape_string($conn, $_POST['mayorFy']);
        $Mayor_Cont  = mysqli_real_escape_string($conn, $_POST['mayorCont']);

        //In House
        //if (inCheck){}
        $in_Am  = mysqli_real_escape_string($conn, $_POST['inAm']);
        $in_Fy  = mysqli_real_escape_string($conn, $_POST['inFy']);

        //Capital Project
        //if (capitalCheck){}
        $Capital_Am  = mysqli_real_escape_string($conn, $_POST['capitalAm']);
        $Capital_Fy  = mysqli_real_escape_string($conn, $_POST['capitalFy']);

        //Cuny2020
        //if (cunyCheck){}
        $Cuny_Am  = mysqli_real_escape_string($conn, $_POST['cunyAm']);
        $Cuny_Fy  = mysqli_real_escape_string($conn, $_POST['cunyFy']);

        //SAM CCAP
        //if (samCheck){}
        $Sam_Am  = mysqli_real_escape_string($conn, $_POST['samAm']);
        $Sam_FY  = mysqli_real_escape_string($conn, $_POST['samFy']);

        //Private Grant
        //if (priCheck){}
        $Price_Am  = mysqli_real_escape_string($conn, $_POST['priAm']);
        $Price_Fy  = mysqli_real_escape_string($conn, $_POST['priFy']);

        //Federal State
        //if (fedCheck){}
        $Federal_Am  = mysqli_real_escape_string($conn, $_POST['fedAm']);
        $Federal_Fy  = mysqli_real_escape_string($conn, $_POST['fedFy']);

        //DCAS/Operationg
        //if (doCheck){}
        $Do_Am  = mysqli_real_escape_string($conn, $_POST['doAm']);
        $Do_FY  = mysqli_real_escape_string($conn, $_POST['doFy']); 

        //DCAS/Cap
        //if (dccheck){}
        $Dc_Am  = mysqli_real_escape_string($conn, $_POST['dcAm']);
        $Dc_FY  = mysqli_real_escape_string($conn, $_POST['dcAm']);

        //Energy Conservation
        //if (energyCheck){}
        $Energy_Am  = mysqli_real_escape_string($conn, $_POST['energyAm']);
        $Energy_Fy  = mysqli_real_escape_string($conn, $_POST['energyFy']);

        $total = $_POST[constCost] + $_POST[designTeam] + $_POST[designCost] + $_POST[manageCost] + $_POST[fe];



        $sql="INSERT INTO `tblproject`(`Proj_Name`, `Proj_Number`,`Proj_Type`, `Proj_St_Date`, `Proj_Comp_Date`, `Proj_Design_Team`, `Proj_Building`, `Proj_Location`, `Proj_Serv_Provider`, `Proj_Status`, `Proj_Design_Cost`, `Proj_Const_Cost`, `Proj_FE_Cost`, `Proj_Management_Cost`, `Proj_Overview`,`Proj_Priority_lvl`,`TotalCost`) VALUES ('$ProjName','$ProjectNumber','$ProjectType','$ProjectStartDate','$CompletionDate','$Desing_Team','$Building','$Location','$Service_Provided','$Status','$Desing_Cost','$Construction_Cost','$FE_Cost','$Management_Cost','$Project_Over','$Priority_Level','$total')";
        
        $sqlfunding = "INSERT INTO `tblfunding`(`BP_Amount`, `BP_FY_received`, `BP_CP#`, `CC_Amount`, `CC_FY_received`, `CC_CP#`, `Mayor_Amount`, `Mayor_FY_received`, `Mayor_CP#`, `In_House_Amount`, `In_House_FY_received`, `Capital_Project_Amount`, `Capital_Project_FY_received`, `CUNY_Amount`, `CUNY_FY_received`, `SAM_Amount`, `SAM_FY_received`, `Private_Amount`, `Private_FY_received`, `Federal_Amount`, `Federal_FY_received`, `DCAS_Amount`, `DCAS_FY_received`, `DCAS_CAP_Amount`, `DCAS_CAP_FY_received`, `Energy_Conserv_Amount`, `Energy_FY_received`) VALUES(            '$Boro_Am','$Boro_Fy','$Boro_Cont','$City_Am','$City_Fy','$City_Cont','$Mayor_Am','$Mayor_Fy','$Mayor_Cont','$in_Am','$in_Fy','$Capital_Am','$Capital_Fy','$Cuny_Am','$Cuny_Fy','$Sam_Am','$Sam_FY','$Price_Am','$Price_Fy','$Federal_Am','$Federal_Fy','$Do_Am','$Do_FY','$Dc_Am','$Dc_FY','$Energy_Am','$Energy_Fy')";


/*
        if (isset ($_POST['submitmeeting'])) // checks for the submit value
        {
            $path = 'files/meetingminutes/'; //folder's name
            $i = 0; 
            while($i<count($_FILES['file']['name']))//counts the number of files
            {
                $name = $_FILES['file']['name'][$i]; //stores the files and files name along with the array
                $path_name = $path.$name;
                $tmp_name = $_FILES['file']['tmp_name'][$i]; //temp for $name
                //$submit = isset($_POST['submit']);
                //$position = strpos($name,"." );
                //$fileextension = substr($name, $position + 1);
                //$fileextension = strtolower($fileextension);
                $description = $_POST["description_entered"]; //description
                if (!empty($description)) {           
                    mysqli_query($conn, "insert into tblproject (proj_minutes_name, proj_minutes_path, proj_minutes_description) values('$name','$path_name', $description)"); //query that stores desc and name
                }
                if (isset($name)) {
                    $path = 'files/meetingminutes/'; //folder's name
                    if( !empty($name)){
                        move_uploaded_file($tmp_name, $path.$name); // function, moves files into www/
                    }
                }
                $i++;
            }
            echo $i++." files were added.";   
        } 

        else if (isset ($_POST['submitbasis'])) // checks for the submit value
        {
            $path = 'files/requestanddesignbasis/'; //folder's name
            $i = 0; 
            while($i<count($_FILES['file']['name']))//counts the number of files
            {
                $name = $_FILES['file']['name'][$i]; //stores the files and files name along with the array
                $path_name = $path.$name;
                $tmp_name = $_FILES['file']['tmp_name'][$i]; //temp for $name
                //$submit = isset($_POST['submit']);
                $position = strpos($name,"." );
                $fileextension = substr($name, $position + 1);
                $fileextension = strtolower($fileextension);
                $description = $_POST["description_entered"]; //description
                //if (!empty($description)) {}
                mysqli_query($conn, "insert into tblproject (proj_design_basis_name, proj_design_basis_path, proj_design_basis_description) values('$name','$path_name', '$description')"); //query that stores desc and name

                if (isset($name)) {
                    $path = 'files/requestanddesignbasis/'; //folder's name
                    if( !empty($name)){
                        move_uploaded_file($tmp_name, $path.$name); // function, moves files into www/
                    }
                }
                $i++;
            }
            echo $i++." files were added.";   
        }


        else if (isset ($_POST['submitScopeChange'])) // checks for the submit value
        {
            $path = 'files/requestforscopechange/'; //folder's name
            $i = 0; 
            while($i<count($_FILES['file']['name']))//counts the number of files
            {
                $name = $_FILES['file']['name'][$i]; //stores the files and files name along with the array
                $path_name = $path.$name;
                $tmp_name = $_FILES['file']['tmp_name'][$i]; //temp for $name
                //$submit = isset($_POST['submit']);
                $position = strpos($name,"." );
                $fileextension = substr($name, $position + 1);
                $fileextension = strtolower($fileextension);
                $description = $_POST["description_entered"]; //description
                //if (!empty($description)) {}
                mysqli_query($conn, "insert into tblproject (Proj_Scope_Changes_Name, Proj_Scope_Changes_Path, Proj_Scope_Changes_Description) values('$name','$path_name', '$description')"); //query that stores desc and name

                if (isset($name)) {
                    $path = 'files/requestforscopechange/'; //folder's name
                    if( !empty($name)){
                        move_uploaded_file($tmp_name, $path.$name); // function, moves files into www/
                    }
                }
                $i++;
            }
            echo $i++." files were added.";   
        }

        else if (isset ($_POST['submitCostEstimates'])) // checks for the submit value
        {
            $path = 'files/costestimates/'; //folder's name
            $i = 0; 
            while($i<count($_FILES['file']['name']))//counts the number of files
            {
                $name = $_FILES['file']['name'][$i]; //stores the files and files name along with the array
                $path_name = $path.$name;
                $tmp_name = $_FILES['file']['tmp_name'][$i]; //temp for $name
                //$submit = isset($_POST['submit']);
                $position = strpos($name,"." );
                $fileextension = substr($name, $position + 1);
                $fileextension = strtolower($fileextension);
                $description = $_POST["description_entered"]; //description
                //if (!empty($description)) {}
                mysqli_query($conn, "insert into tblproject (Proj_Cost_Estimates_Name, Proj_Cost_Estimates_Path, Proj_Cost_Estimates_Description) values('$name','$path_name', '$description')"); //query that stores desc and name

                if (isset($name)) {
                    $path = 'files/costestimates/'; //folder's name
                    if( !empty($name)){
                        move_uploaded_file($tmp_name, $path.$name); // function, moves files into www/
                    }
                }
                $i++;
            }
            echo $i++." files were added.";   
        }

        else if (isset ($_POST['submitBuildingDepart'])) // checks for the submit value
        {
            $path = 'files/buildingdeparment/'; //folder's name
            $i = 0; 
            while($i<count($_FILES['file']['name']))//counts the number of files
            {
                $name = $_FILES['file']['name'][$i]; //stores the files and files name along with the array
                $path_name = $path.$name;
                $tmp_name = $_FILES['file']['tmp_name'][$i]; //temp for $name
                //$submit = isset($_POST['submit']);
                $position = strpos($name,"." );
                $fileextension = substr($name, $position + 1);
                $fileextension = strtolower($fileextension);
                $description = $_POST["description_entered"]; //description
                //if (!empty($description)) {}
                mysqli_query($conn, "insert into tblproject (Proj_Building_Dept_Name, Proj_Building_Dept_Name, Proj_Building_Dept_Description) values('$name','$path_name', '$description')"); //query that stores desc and name

                if (isset($name)) {
                    $path = 'files/buildingdeparment/'; //folder's name
                    if( !empty($name)){
                        move_uploaded_file($tmp_name, $path.$name); // function, moves files into www/
                    }
                }
                $i++;
            }
            echo $i++." files were added.";   
        }

        else if (isset ($_POST['submitBidDocument'])) // checks for the submit value
        {
            $path = 'files/biddocuments/'; //folder's name
            $i = 0; 
            while($i<count($_FILES['file']['name']))//counts the number of files
            {
                $name = $_FILES['file']['name'][$i]; //stores the files and files name along with the array
                $path_name = $path.$name;
                $tmp_name = $_FILES['file']['tmp_name'][$i]; //temp for $name
                //$submit = isset($_POST['submit']);
                $position = strpos($name,"." );
                $fileextension = substr($name, $position + 1);
                $fileextension = strtolower($fileextension);
                $description = $_POST["description_entered"]; //description
                //if (!empty($description)) {}
                mysqli_query($conn, "insert into tblproject (Proj_Bid_Doc_Name, Proj_Bid_Doc_Path, Proj_Bid_Doc_Description) values('$name','$path_name', '$description')"); //query that stores desc and name

                if (isset($name)) {
                    $path = 'files/biddocuments/'; //folder's name
                    if( !empty($name)){
                        move_uploaded_file($tmp_name, $path.$name); // function, moves files into www/
                    }
                }
                $i++;
            }
            echo $i++." files were added.";   
        }

        else if (isset ($_POST['submitInspectReport'])) // checks for the submit value
        {
            $path = 'files/inspectionreport/'; //folder's name
            $i = 0; 
            while($i<count($_FILES['file']['name']))//counts the number of files
            {
                $name = $_FILES['file']['name'][$i]; //stores the files and files name along with the array
                $path_name = $path.$name;
                $tmp_name = $_FILES['file']['tmp_name'][$i]; //temp for $name
                //$submit = isset($_POST['submit']);
                $position = strpos($name,"." );
                $fileextension = substr($name, $position + 1);
                $fileextension = strtolower($fileextension);
                $description = $_POST["description_entered"]; //description
                //if (!empty($description)) {}
                mysqli_query($conn, "insert into tblproject (Proj_Inspection_Report_Name, Proj_Inspection_Report_Path, Proj_Inspection_Report_Description) values('$name','$path_name', '$description')"); //query that stores desc and name

                if (isset($name)) {
                    $path = 'files/inspectionreport/'; //folder's name
                    if( !empty($name)){
                        move_uploaded_file($tmp_name, $path.$name); // function, moves files into www/
                    }
                }
                $i++;
            }
            echo $i++." files were added.";   
        }

        else if (isset ($_POST['submitFE'])) // checks for the submit value
        {
            $path = 'files/fande/'; //folder's name
            $i = 0; 
            while($i<count($_FILES['file']['name']))//counts the number of files
            {
                $name = $_FILES['file']['name'][$i]; //stores the files and files name along with the array
                $path_name = $path.$name;
                $tmp_name = $_FILES['file']['tmp_name'][$i]; //temp for $name
                //$submit = isset($_POST['submit']);
                $position = strpos($name,"." );
                $fileextension = substr($name, $position + 1);
                $fileextension = strtolower($fileextension);
                $description = $_POST["description_entered"]; //description
                //if (!empty($description)) {}
                mysqli_query($conn, "insert into tblproject (Proj_FE_Name, Proj_FE_Path, Proj_FE_Description) values('$name','$path_name', '$description')"); //query that stores desc and name

                if (isset($name)) {
                    $path = 'files/fande/'; //folder's name
                    if( !empty($name)){
                        move_uploaded_file($tmp_name, $path.$name); // function, moves files into www/
                    }
                }
                $i++;
            }
            echo $i++." files were added.";   
        }

        else if (isset ($_POST['submitCloseOut'])) // checks for the submit value
        {
            $path = 'files/closeout/'; //folder's name
            $i = 0; 
            while($i<count($_FILES['file']['name']))//counts the number of files
            {
                $name = $_FILES['file']['name'][$i]; //stores the files and files name along with the array
                $path_name = $path.$name;
                $tmp_name = $_FILES['file']['tmp_name'][$i]; //temp for $name
                //$submit = isset($_POST['submit']);
                $position = strpos($name,"." );
                $fileextension = substr($name, $position + 1);
                $fileextension = strtolower($fileextension);
                $description = $_POST["description_entered"]; //description
                //if (!empty($description)) {}
                mysqli_query($conn, "insert into tblproject (Proj_Closeout_Name, Proj_Closeout_Path, Proj_Closeout_Description) values('$name','$path_name', '$description')"); //query that stores desc and name

                if (isset($name)) {
                    $path = 'files/closeout/'; //folder's name
                    if( !empty($name)){
                        move_uploaded_file($tmp_name, $path.$name); // function, moves files into www/
                    }
                }
                $i++;
            }
            echo $i++." files were added.";   
        }*/
        
        // 

        if(mysqli_query($conn, $sql)){
            
            /*$result = mysqli_query($conn,"select proj_ID from tblproject where proj_name='$project_name';");
            $respondent = mysql_fetch_array($result)
            $proj_id='proj_id';*/   
            
            /*$price = mysql_query("SELECT Proj_Type FROM tblproject WHERE Proj_Name = '$ProjName'");
            $result = mysql_fetch_array($price);
            $projid = $result['Proj_Type'];
            echo $projid ;*/
            
            
            
            if(mysqli_query($conn, $sqlfunding))
            {
            echo "Data Added";
            }
            else
                echo "Information not entered: $sql.".mysqli_error($conn);*/
                
        }
        else 
            echo "Information not entered: $sql.".mysqli_error($conn);

        ?>

    </body>

</html>